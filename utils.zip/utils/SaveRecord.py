import numpy as np
import pandas as pd
import math

def record_output(oa_ae, aa_ae, kappa_ae, element_acc_ae, training_time_ae, testing_time_ae, path):
    f = open(path, 'a')
    f.write("----------------------------------" + " 实验结果 ----------------------------------" + '\n')
    f.write("----------------------------------" + " 每一轮的结果 ----------------------------------" + '\n')
    sentence0 = 'OAs for each iteration are:' + str(oa_ae) + '\n'
    f.write(sentence0)
    sentence1 = 'AAs for each iteration are:' + str(aa_ae) + '\n'
    f.write(sentence1)
    sentence2 = 'KAPPAs for each iteration are:' + str(kappa_ae) + '\n' + '\n'
    f.write(sentence2)

    f.write("----------------------------------" + " 结果加标准差 ----------------------------------" + '\n')
    sentence3 = 'mean_OA ± std_OA is: ' + str(np.mean(oa_ae)) + ' ± ' + str(np.std(oa_ae)) + '\n'
    f.write(sentence3)
    sentence4 = 'mean_AA ± std_AA is: ' + str(np.mean(aa_ae)) + ' ± ' + str(np.std(aa_ae)) + '\n'
    f.write(sentence4)
    sentence5 = 'mean_KAPPA ± std_KAPPA is: ' + str(np.mean(kappa_ae)) + ' ± ' + str(np.std(kappa_ae)) + '\n' + '\n'
    f.write(sentence5)

    f.write("------------------" + " 训练时间和测试时间 -------------------" + '\n')
    sentence6 = 'Training time is: ' + str(np.sum(training_time_ae)) + '\n'
    f.write(sentence6)
    sentence7 = 'Testing time is: ' + str(np.sum(testing_time_ae)) + '\n' + '\n'
    f.write(sentence7)

    f.write("------------------" + " 每一类的oa均值和方差 -------------------" + '\n')
    element_mean = np.mean(element_acc_ae, axis=0)
    element_std = np.std(element_acc_ae, axis=0)
    sentence8 = "Mean of all elements in confusion matrix: " + str(element_mean) + '\n'
    f.write(sentence8)
    sentence9 = "Standard deviation of all elements in confusion matrix: " + str(element_std) + '\n'
    f.write(sentence9)
    f.write('\n')
    f.write('\n')
    f.close()

def listReverse(nums):
    ans = []
    for i in range(len(nums[0])):
        num = []
        for j in range(len(nums)):
            num.append(nums[j][i])
        ans.append(num)
    return ans

"""将实验结果保存在excel表格中"""
def record_output_excel(iter,oa_ae, aa_ae, kappa_ae, element_acc_ae,path):
    iter = [str(i+1) for i in range(iter)]
    oa_ae = [str(i) for i in oa_ae]
    aa_ae = [str(i) for i in aa_ae]
    kappa_ae = [str(i) for i in kappa_ae]

    dfData1 = {
        'iter': iter,
        'OA': oa_ae,
        'AA': aa_ae,
        'Kappa': kappa_ae
    }
    df1 = pd.DataFrame(dfData1)

    element_acc_ae = listReverse(element_acc_ae)
    # element_acc_ae_10 = []
    # for i in range(len(element_acc_ae)):
    #     element = list(map(str, element_acc_ae[i]))
    #     element_acc_ae[i][:] = element[:]
    #     element_acc_ae_10.append(element[5:15])
    for i in range(len(element_acc_ae)):
        element = list(map(str, element_acc_ae[i]))
        element_acc_ae[i][:] = element[:]
    dfData2 = {'iter': iter}
    for i in range(len(element_acc_ae)):
        dfData2[str(i+1)] = element_acc_ae[i]
    df2 = pd.DataFrame(dfData2)

    dfData3  = {
        'iter': iter,
        'OA': oa_ae,
        'AA': aa_ae,
        'Kappa': kappa_ae,
        }
    for i in range(len(element_acc_ae)):
        dfData3[str(i+1)] = element_acc_ae[i]
    df3 = pd.DataFrame(dfData3)


    with pd.ExcelWriter(path) as writer:
        df1.to_excel(writer,index=False,sheet_name='OA_AA_Kappa')
        df2.to_excel(writer, index=False, sheet_name='element_oa')
        df3.to_excel(writer, index=False, sheet_name='OA_AA_Kappa_element_oa')

