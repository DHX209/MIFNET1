import numpy as np
import pandas as pd
import math
import torch
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import os
import sklearn.manifold as manifold
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

#存储图像中的一些数据
fc_dict = {
    'IP': [56, 33, 13, 1.0, 0.5],
    'PU': [52, 34, 17, 1.0, 1.0],
    'HU': [59, 40, 23, 6.8, 0.65],
    '4': [59, 40, 23, 1.0, 0.7],
    'XA': [120, 72, 36, 1.0, 1],
    'ZY': [55, 28, 8, 1, 1],
    'LK': [120, 72, 36, 1.0, 1],
    'HC': [56, 33, 13, 1.0, 0.5],
}

data_name_dict = {
    'PU': 'PaviaU',
    'IP': 'Indian_pines',
    'HU': 'Houston',
    'SA': 'Salinas',
    'KSC': 'KSC',
    'BT': 'Botswana',
    'HY': 'HyRANK_satellite',
    'HU2018': 'Houston2018',
    'HC': 'HanChuan',
    'HH': 'HongHu',
    'LK': 'LongKou',
    'ZY': 'ZY_hhk',
    'XA': 'XiongAn'
}

class_name_dict = {
    'PU': ["Asphalt", "Meadows", "Gravel", "Trees",
           "Painted metal sheets", "Bare Soil", "Bitumen",
           "Self-Blocking Bricks", "Shadows"],
    'SA': ["Brocoli_green_weeds_1", "Brocoli_green_weeds_2", "Fallow", "Fallow_rough_plow",
           "Fallow_smooth", "Stubble", "Celery", "Grapes_untrained", "Soil_vinyard_develop",
           "Corn_senesced_green_weeds", "Lettuce_romaine_4wk", "Lettuce_romaine_5wk",
           "Lettuce_romaine_6wk", "Lettuce_romaine_7wk", "Vinyard_untrained", "Vinyard_vertical_trellis"],
    'IP': ["Alfalfa", "Corn-notill", "Corn-mintill", "Corn", "Grass-pasture", "Grass-trees",
           "Grass-pasture-mowed", "Hay-windrowed", "Oats", "Soybean-notill", "Soybean-mintill",
           "Soybean-clean", "Wheat", "Woods", "Buildings-Grass-Trees-Drives", "Stone-Steel-Towers"],
    'BT': ["Water", "Hippo grass", "Floodplain grasses 1", "Floodplain grasses 2", "Reeds", "Riparian",
           "Firescar", "Island interior", "Acacia woodlands", "Acacia shrublands", "Acacia grasslands",
           "Short mopane", "Mixed mopane", "Exposed soils"],
    'KSC': ["Scrub", "Willow swamp", "Cabbage palm hammock", "Cabbage palm/oak hammock",
            "Slash pine", "Oak/broadleaf hammock", "Hardwood swamp", "Graminoid marsh",
            "Spartina marsh", "Cattail marsh", "Salt marsh", "Mud flats", "Wate"],
    'HU': ['Healthy grass', 'Stressed grass', 'Synthetic grass', 'Trees',
           'Soil', 'Water', 'Residential', 'Commercial', 'Road', 'Highway',
           'Railway', 'Parking Lot1', 'Parking Lot2', 'Tennis court', 'Running track'],
    'HU2018': ['Healthy Grass', 'Stressed Grass', 'Artificial Turf', 'Evergreen Trees',
               'Deciduous Trees', 'Bare Earth', 'Water', 'Residential Buildings',
               'Non-Residential Buildings', 'Roads', 'Sidewalks', 'Crosswalks',
               'Major Thoroughfares', 'Highways', 'Railways', 'Paved Parking Lots',
               'Unpaved Parking Lots', 'Cars', 'Trains', 'Stadium Seats'],
    'XA': ['Acer negundo Linn', 'Willow', 'Elm', 'Paddy', 'Chinese Pagoda Tree',
           'Fraxinus chinensis', 'Koelreuteria paniculata', 'Water', 'Bare land',
           'Paddy stubble', 'Robinia pseudoacacia', 'Corn', 'Pear', 'Soya', 'Alamo', 'Vegetable field',
           'Sparsewood', 'Meadow', 'Peach', 'Building'],
    'ZY': ['Reed', 'Spartina alterniflora', 'Salt filter pond', 'Salt evaporation pond',
           'Dry pond', 'Tamarisk', 'Salt pan', 'Seepweed', 'River', 'Sea', 'Mudbank', 'Tidal creek',
           'Fallow land', 'Ecological restoration pond', 'Robinia', 'Fishpond', 'Pit pond',
           'Building', 'Bare land', 'Paddyfield', 'Cotton', 'Soybean', 'Corn'],
    'LK': ['Corn', 'Cotton', 'Sesame', 'Broad-leaf soybean', 'Narrow-leaf soybean', 'Rice', 'Water',
           'Roads and houses', 'Mixed weed'],
    'HC': ['Strawberry', 'Cowpea', 'Soybean', 'Sorghum',
           'Water spinach', 'Watermelon', 'Greens', 'Trees', 'Grass', 'Red roof',
           'Gray roof', 'Plastic', 'Bare soil', 'Road', 'Bright object', 'Water']
}

#给每一个类别生成一个彩色标签
def list_to_colormap(x_list):
    y = np.zeros((x_list.shape[0], 3))
    for index, item in enumerate(x_list):
        if item == 0:
            y[index] = np.array([255, 0, 0]) / 255.
        if item == 1:
            y[index] = np.array([0, 255, 0]) / 255.
        if item == 2:
            y[index] = np.array([0, 0, 255]) / 255.
        if item == 3:
            y[index] = np.array([255, 255, 0]) / 255.
        if item == 4:
            y[index] = np.array([0, 255, 255]) / 255.
        if item == 5:
            y[index] = np.array([255, 0, 255]) / 255.
        if item == 6:
            y[index] = np.array([192, 192, 192]) / 255.
        if item == 7:
            y[index] = np.array([128, 128, 128]) / 255.
        if item == 8:
            y[index] = np.array([128, 0, 0]) / 255.
        if item == 9:
            y[index] = np.array([128, 128, 0]) / 255.
        if item == 10:
            y[index] = np.array([0, 128, 0]) / 255.
        if item == 11:
            y[index] = np.array([128, 0, 128]) / 255.
        if item == 12:
            y[index] = np.array([0, 128, 128]) / 255.
        if item == 13:
            y[index] = np.array([0, 0, 128]) / 255.
        if item == 14:
            y[index] = np.array([255, 165, 0]) / 255.
        if item == 15:
            y[index] = np.array([255, 215, 0]) / 255.
        if item == 16:
            y[index] = np.array([0, 0, 0]) / 255.
        if item == 17:
            y[index] = np.array([215, 255, 0]) / 255.
        if item == 18:
            y[index] = np.array([0, 255, 215]) / 255.
        if item == -1:
            y[index] = np.array([0, 0, 0]) / 255.
    return y

def class_to_colormap(item):
    if item == 0:
        color = np.array([255, 0, 0]) / 255.
    if item == 1:
        color = np.array([0, 255, 0]) / 255.
    if item == 2:
        color = np.array([0, 0, 255]) / 255.
    if item == 3:
        color= np.array([255, 255, 0]) / 255.
    if item == 4:
        color = np.array([0, 255, 255]) / 255.
    if item == 5:
        color = np.array([255, 0, 255]) / 255.
    if item == 6:
        color = np.array([192, 192, 192]) / 255.
    if item == 7:
        color = np.array([128, 128, 128]) / 255.
    if item == 8:
        color = np.array([128, 0, 0]) / 255.
    if item == 9:
        color = np.array([128, 128, 0]) / 255.
    if item == 10:
        color = np.array([0, 128, 0]) / 255.
    if item == 11:
        color = np.array([128, 0, 128]) / 255.
    if item == 12:
        color = np.array([0, 128, 128]) / 255.
    if item == 13:
        color = np.array([0, 0, 128]) / 255.
    if item == 14:
        color = np.array([255, 165, 0]) / 255.
    if item == 15:
        color = np.array([255, 215, 0]) / 255.
    if item == 16:
        color = np.array([0, 0, 0]) / 255.
    if item == 17:
        color = np.array([215, 255, 0]) / 255.
    if item == 18:
        color = np.array([0, 255, 215]) / 255.
    if item == -1:
        color = np.array([0, 0, 0]) / 255.
    return color


#标准化数据
def featureNormalize(X, type, eps=0.0):
    if type == 1:
        mu = np.mean(X, 0)
        X_norm = X - mu
        sigma = np.std(X_norm, 0)
        X_norm = X_norm / sigma
        m = np.diag(1 / sigma)
        # return X_norm
        return X_norm, m
    elif type == 2:
        minX = np.min(X, 0)
        maxX = np.max(X, 0)
        X_norm = X - minX
        X_norm = X_norm / (maxX - minX + eps)
        return X_norm
    elif type == 3:
        sigma = np.std(X, 0)
        X_norm = X / sigma
        return X_norm
#绘制假彩色图像
#将获取的输入矩阵转换为RGB或者灰度图像
def matrgb(mat,eps=0.0):
    sz = np.shape(mat)
    if len(sz) == 3:
        r = np.reshape(mat[:,:,0],(sz[0] * sz[1]))
        r = np.expand_dims(np.reshape(featureNormalize(r, type=2, eps=eps), [sz[0], sz[1]]), axis=-1) #归一化，将最小值映射为0，最大值映射为1
        g = np.reshape(mat[:,:,1],(sz[0] * sz[1]))
        g = np.expand_dims(np.reshape(featureNormalize(g, type=2, eps=eps), [sz[0], sz[1]]), axis=-1)
        b = np.reshape(mat[:,:,2],(sz[0] * sz[1]))
        b = np.expand_dims(np.reshape(featureNormalize(b, type=2, eps=eps), [sz[0], sz[1]]), axis=-1)
        rgb = np.concatenate((r,g,b),axis=-1)
        return rgb
    else:
        gray = gray = np.reshape(mat[:, :], [sz[0] * sz[1]])
        gray = np.reshape(featureNormalize(gray, type=2, eps=eps), [sz[0], sz[1]])
        return gray

#绘制假彩色图像
def draw_false_color(data,dataset_name):
    print("--------" + " 绘制false color map-----------")
    rgb = fc_dict[dataset_name]
    data = data[:,:,rgb[0:3]]
    data = matrgb(data)
    plt.imsave('./map/datamap/' + data_name_dict[dataset_name] + '_' + str(rgb[0]) + '_' + str(rgb[1]) + '_' + str(rgb[2]) + '_false_color.png',data)
    # plt.imshow(data)
    plt.axis('off')
    plt.show()
    print("--------" + " 绘制false color map finished-----------")

#绘制聚类结果
def draw_cluster(test_label,cluster,class_num,oa,data_name,model_name):
    """
    all_data:所有的数据
    test_label:测试集的真实标签 由于使用了独立热编码，所以使用前需要转换为一维数组
    cluster:模型分类之后的结果，没有取最大值，是一个概率分布[batch_size, num_class]
    oa:整体精度，找出最好的一个iter，计算出模型的分类OA
    aa:平均精度，找出最好的一个iter，计算出模型的分类AA
    data_name:数据集的名字
    model_name:模型的名字
    """
    # test_label = np.array(np.argmax(test_label, axis=1)) #将独热编码的标签转换为一维数组，找出每一个样本的真实标签
    #使相似的数据点在降维后的空间中更加接近，不同的数据点在降维后的空间中更加远离
    tsne = manifold.TSNE(n_components=2, init='pca') # 使用TSNE进行降维，降到2维，以绘制散点图
    #输出；将高维数据转换到二维空间中的坐标，每一个数据点对应一个坐标，用来绘制散点图。
    X_tsne = tsne.fit_transform(cluster) # 拟合模型并转换数据，fit学习最佳的降维方法，transformer进行数据转换
    x_min, x_max = X_tsne.min(0), X_tsne.max(0)
    X_norm = (X_tsne - x_min) / (x_max - x_min)
    plt.figure()

    for i in range(class_num):
        palette = class_to_colormap(i)
        index = np.where(test_label == i) #找出每一个类别的索引
        xx1 = X_norm[index, 0] #找出每一个类别的x坐标
        yy1 = X_norm[index, 1] #找出每一个类别的y坐标
        plt.scatter(xx1,yy1,color=palette)

    if not os.path.exists('./map/cluster/'):
        os.makedirs('./map/cluster/')
    plt.savefig('./map/cluster/'+model_name+data_name+'_OA_'+str(round(oa,3))
                + '.png', dpi=600, bbox_inches='tight')
    plt.savefig('./map/cluster/' + model_name + data_name + '_OA_' + str(round(oa, 3))
                + '.svg', dpi=600, bbox_inches='tight')

#绘制训练集、测试集和真实图片
def draw_gt(gt, data_name, class_num, train_indices, test_indices, border=True, ):
    print("--------" + " 绘制gt map-----------")
    """param border: 是否绘制边界"""
    h, w= gt.shape # 获取HSI图像的高、宽
    lab = np.reshape(gt, (h * w, 1)) # 将HSI图像展平
    # lab[lab == 0] = -1 # 将背景类别标签设置为-1
    lab = lab - 1 # 将类别标签减1，使类别标签从0开始，背景从-1开始
    train_lab = -1 * np.ones_like(lab) # 初始化训练样本的类别标签
    train_lab[train_indices] = lab[train_indices] # 获取训练样本的类别标签
    test_lab = -1 * np.ones_like(lab)
    test_lab[test_indices] = lab[test_indices] # 获取测试样本的类别标签

    palette = list_to_colormap(lab) # 生成彩色标签
    X_result = np.reshape(palette, (h, w, 3)) # 将彩色标签展平

    palette_train = list_to_colormap(train_lab) # 生成训练样本的彩色标签
    X_train = np.reshape(palette_train, (h, w, 3)) # 将训练样本的彩色标签展平

    palette_test = list_to_colormap(test_lab) # 生成测试样本的彩色标签
    X_test = np.reshape(palette_test, (h, w, 3)) # 将测试样本的彩色标签展平

    if border:
        new_X_result = np.zeros([h + 4, w + 4, 3])
        new_X_result[2:-2, 2:-2, :] = X_result
        X_result = new_X_result

    plt.imsave('./map/datamap/' + data_name_dict[str(data_name)] + '_gt.png', X_result)
    # plt.imshow(X_result)

    plt.imsave('./map/datamap/' + data_name_dict[str(data_name)] + '_train_gt.png', X_train)
    # plt.imshow(X_train)

    plt.imsave('./map/datamap/' + data_name_dict[str(data_name)] + '_test_gt.png', X_test)
    # plt.imshow(X_test)

    plt.axis('off')
    plt.show()
    print("--------" + " 绘制gt map finished-----------")

#绘制颜色条
def draw_bar(data_name='PU',class_num=9):
    bar_w = 0.1
    bar_h = 0.03
    gap_h = 0.01
    fig1 = plt.figure()
    ax1 = fig1.add_subplot(111, aspect='equal') # 创建子图，设置长宽比

    palette = np.array([i for i in range(class_num)])
    palette = list_to_colormap(palette)
    cname = class_name_dict[str(data_name)]

    for idx in range(class_num):
        i = class_num - idx - 1 # 从下往上绘制，从映射的末尾往上绘制
        c = palette[i,:] # 获取类别标签对应的颜色
        rect = patches.Rectangle((0, (bar_h + gap_h) * idx), bar_w, bar_h, color=c) # 创建矩形
        ax1.add_patch(rect)

        cn = cname[i] # 获取类别名称
        plt.text(bar_w * 1.2, (bar_h + gap_h) * idx + bar_h / 8, cn, fontsize=16) # 绘制类别名称

    plt.axis('off')
    frame = plt.gca() # 获取当前子图
    frame.axes.get_xaxis().set_visible(False) # 设置x轴不可见
    frame.axes.get_yaxis().set_visible(False) # 设置y轴不可见

    plt.xlim(xmin=0, xmax=bar_w * 3) # 设置x轴范围
    plt.ylim(ymin=0, ymax=(bar_h + gap_h) * class_num) # 设置y轴范围

    fig1.savefig('./map/datamap/' + data_name_dict[str(data_name)] + '_bar.png', format='png', bbox_inches='tight',
                 pad_inches=0.0)

#生成训练之后的特征图
def draw_testresult(gt,test_indices,pre_test,best_oa,data_name='PU',model_name='DBCTNet', border=False):
    h, w = gt.shape  # 获取HSI图像的高、宽
    lab = np.reshape(gt, (h * w, 1))  # 将HSI图像展平
    lab = lab - 1  # 将类别标签减1，使类别标签从0开始，背景从-1开始
    lab_copy = np.array(lab)
    lab_copy[test_indices] = np.array(np.reshape(pre_test,(-1,1))) # 获取测试样本的类别标签

    palette = list_to_colormap(lab_copy)  # 生成彩色标签
    X_result = np.reshape(palette, (h, w, 3))  # 将彩色标签展平

    plt.imsave(
        './map/classification_maps/'+ str(model_name) + "_" + data_name_dict[str(data_name)] + str(round(best_oa, 3)) +'_testresult.png',X_result)
    if border:
        new_X_result = np.zeros([h + 4, w + 4, 3])
        new_X_result[2:-2, 2:-2, :] = X_result
        X_result = new_X_result

def draw_allresult(gt,pre_test,best_oa,data_name='PU',model_name='DBCTNet', border=False):
    h, w = gt.shape
    pre_test = np.array(pre_test)
    palette = list_to_colormap(pre_test)
    X_result = np.reshape(palette, (h, w, 3))

    plt.imsave(
        './map/classification_maps/' + data_name_dict[str(data_name)] + str(round(best_oa, 3)) + '_allresult.png',
        X_result)
    if border:
        new_X_result = np.zeros([h + 4, w + 4, 3])
        new_X_result[2:-2, 2:-2, :] = X_result
        X_result = new_X_result
