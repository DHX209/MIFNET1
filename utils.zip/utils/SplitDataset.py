from sklearn.model_selection import train_test_split
from collections import Counter
import numpy as np
import torch
import time
import math
import numpy as np
from sklearn.model_selection import train_test_split
from collections import Counter

def get_data_index(gt, data_name, class_num, train_ratio):

    print("gt.shape:", gt.shape)

    # 1. 统计每一类像素的总数
    data_num = []  # 存放每一类像素的数量
    for i in range(class_num):
        idx = np.where(gt == i + 1)[-1]  # 获取标签为 i+1 的像素索引
        data_num.append(len(idx))  # 记录当前类别的像素数量
    data_num = np.array(data_num)

    # 2. 计算每一类训练集和验证集的数量，确保最小数量
    train_num = [max(math.ceil(i * train_ratio), 1) for i in data_num]  # 训练集数量 (最小为5)
    val_num = [max(math.ceil(i * train_ratio), 1) for i in data_num]   # 验证集数量 (最小为3)

    print('all_num:', data_num, "all_sum:", sum(data_num))
    print('train_num:', train_num, "train_sum:", sum(train_num))
    print('val_num:', val_num, "val_sum:", sum(val_num))
    print('test_num:', np.subtract(data_num, np.add(train_num, val_num)),
          "test_sum:", sum(np.subtract(data_num, np.add(train_num, val_num))))

    # 3. 计算类别采样权重 (用于不平衡数据集)
    total_w = sum(train_num) / class_num  # 每个类别平均的样本数量
    sampler = [total_w / train_num[i] for i in range(class_num)]  # 计算每个类别的采样权重

    # 4. 选择训练集索引
    train_rand_index = []  # 每类的训练集索引
    for i in range(class_num):
        idx = np.where(gt == i + 1)[-1]  # 获取当前类别的所有像素索引
        rand_list = [j for j in range(len(idx))]  # 索引列表
        rand_idx = np.random.choice(rand_list, int(train_num[i]), replace=False)  # 随机抽取训练集索引
        rand_real_idx_per_class = idx[rand_idx]  # 训练集实际像素索引
        train_rand_index.append(rand_real_idx_per_class)
    train_rand_index = np.array(train_rand_index, dtype=object)

    # 将所有训练集索引合并为一个列表
    train_data_index = []
    for c in range(train_rand_index.shape[0]):
        a = train_rand_index[c]
        for j in range(a.shape[0]):
            train_data_index.append(a[j])

    # 5. 选择验证集索引
    val_rand_index = []  # 每类的验证集索引
    for i in range(class_num):
        idx = np.where(gt == i + 1)[-1]  # 获取当前类别的所有像素索引
        idx_val = np.array(list(set(idx) - set(train_rand_index[i])))  # 剔除训练集索引，剩余为验证集候选
        rand_list = [j for j in range(idx_val.shape[0])]
        rand_idx = np.random.choice(rand_list, int(val_num[i]), replace=False)  # 随机抽取验证集索引
        rand_real_idx_per_class = idx_val[rand_idx]
        val_rand_index.append(rand_real_idx_per_class)
    val_rand_index = np.array(val_rand_index, dtype=object)

    # 将所有验证集索引合并为一个列表
    val_data_index = []
    for c in range(val_rand_index.shape[0]):
        a = val_rand_index[c]
        for j in range(a.shape[0]):
            val_data_index.append(a[j])

    # 6. 选择测试集索引
    """ 测试集为：总像素 - 背景像素 - 训练集像素 - 验证集像素 """
    all_data_index = [i for i in range(len(gt))]  # 所有像素的索引
    background_idx = np.where(gt == 0)[-1]  # 背景像素索引
    test_data_index = set(all_data_index) - set(train_data_index) - set(background_idx) - set(val_data_index)
    test_data_index = list(test_data_index)  # 转换为列表

    # 返回训练、验证、测试和所有数据的索引
    return train_data_index, val_data_index, test_data_index, all_data_index


def generate_iter(train_indices, val_indices, test_indices, all_indices,
                  all_data, gt, batch_size, class_num, device):

    # 1. 提取训练数据和标签
    train_data = all_data[train_indices, :, :, :, :]  # 根据训练索引提取数据
    train_label = gt[train_indices] - 1              # 标签减 1，使标签从 0 开始

    # 2. 提取验证数据和标签
    val_data = all_data[val_indices, :, :, :, :]
    val_label = gt[val_indices] - 1

    # 3. 提取测试数据和标签
    test_data = all_data[test_indices, :, :, :, :]
    test_label = gt[test_indices] - 1

    # 4. 提取完整数据和标签
    all_label = gt - 1

    # 5. 转换为 PyTorch 张量 (TensorDataset)
    # 训练集
    x_train = torch.from_numpy(train_data).type(torch.FloatTensor)  # 转换为 FloatTensor
    y_train = torch.from_numpy(train_label).type(torch.LongTensor)  # 转换为 LongTensor
    train_dataset = torch.utils.data.TensorDataset(x_train, y_train)

    # 验证集
    x_val = torch.from_numpy(val_data).type(torch.FloatTensor)
    y_val = torch.from_numpy(val_label).type(torch.LongTensor)
    val_dataset = torch.utils.data.TensorDataset(x_val, y_val)

    # 测试集
    x_test = torch.from_numpy(test_data).type(torch.FloatTensor)
    y_test = torch.from_numpy(test_label).type(torch.LongTensor)
    test_dataset = torch.utils.data.TensorDataset(x_test, y_test)

    # 完整数据集
    x_all = torch.from_numpy(all_data).type(torch.FloatTensor)
    y_all = torch.from_numpy(all_label).type(torch.LongTensor)
    all_dataset = torch.utils.data.TensorDataset(x_all, y_all)

    # 6. 使用 DataLoader 创建数据迭代器
    # 训练数据加载器 (打乱数据用于训练)
    train_iter = torch.utils.data.DataLoader(
        dataset=train_dataset,
        batch_size=batch_size,
        shuffle=True,  # 训练数据需要随机打乱
        num_workers=0,  # 设置工作进程数
    )

    # 验证数据加载器 (不打乱数据)
    val_iter = torch.utils.data.DataLoader(
        dataset=val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
    )

    # 测试数据加载器 (不打乱数据)
    test_iter = torch.utils.data.DataLoader(
        dataset=test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
    )

    # 完整数据加载器 (不打乱数据)
    all_iter = torch.utils.data.DataLoader(
        dataset=all_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
    )

    # 7. 返回所有数据加载器
    return train_iter, val_iter, test_iter, all_iter
