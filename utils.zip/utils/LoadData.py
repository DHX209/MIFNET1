import scipy.io as sio
import numpy as np
import math
from sklearn import preprocessing

def load_data(dataset):
    data_path = 'dataset/'
    if dataset == 'PU':
        data = sio.loadmat(data_path + 'PaviaU.mat')['paviaU']
        labels = sio.loadmat(data_path + 'PaviaU_gt.mat')['paviaU_gt']
    elif dataset == 'IP':
        data = sio.loadmat(data_path + 'Indian_pines_corrected.mat')['indian_pines_corrected']
        labels = sio.loadmat(data_path + 'Indian_pines_gt.mat')['indian_pines_gt']
    elif dataset == 'HC':
        data = sio.loadmat(data_path + 'WHU_Hi_HanChuan.mat')['WHU_Hi_HanChuan']
        labels = sio.loadmat(data_path + 'WHU_Hi_HanChuan_gt.mat')['WHU_Hi_HanChuan_gt']
    elif dataset == 'SA':
        data = sio.loadmat(data_path + 'Salinas_corrected.mat')['salinas_corrected']
        labels = sio.loadmat(data_path + 'Salinas_gt.mat')['salinas_gt']
    elif dataset == 'KSC':
        data = sio.loadmat(data_path + 'Kennedy_space_center/KSC.mat')['KSC']
        labels = sio.loadmat(data_path + 'Kennedy_space_center/KSC_gt.mat')['KSC_gt']
    elif dataset == 'SV':
        data = sio.loadmat(data_path + 'Salinas/Salinas_corrected.mat')['Botswana']
        labels = sio.loadmat(data_path + 'Salinas/Salinas_gt.mat')['Botswana_gt']
    elif dataset == 'PC':
        data = sio.loadmat(data_path + 'Pavia_center/Pavia.mat')['pavia']
        labels = sio.loadmat(data_path + 'Pavia_center/Pavia_gt.mat')['pavia_gt']
    elif dataset == 'LK':
        data = sio.loadmat(data_path + 'WHU_Hi_LongKou.mat')['WHU_Hi_LongKou']
        labels = sio.loadmat(data_path + 'WHU_Hi_LongKou_gt.mat')['WHU_Hi_LongKou_gt']
    else:
        print('Please add your dataset.')
    return data, labels

def data_stand(data):
    height, width, bands = data.shape
    data = data.reshape(height * width, bands)
    min_max = preprocessing.StandardScaler()
    data = min_max.fit_transform(data)
    # data = preprocessing.scale(data)
    data = np.reshape(data, [height, width, bands])
    return data